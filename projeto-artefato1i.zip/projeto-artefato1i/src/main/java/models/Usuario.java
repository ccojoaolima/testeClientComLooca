
package models;

import com.sun.jna.platform.win32.OaIdl;
import javax.sql.DataSource;
import org.apache.commons.dbcp2.BasicDataSource;
import org.springframework.jdbc.core.JdbcTemplate;

/**
 *
 * @author João Henrique
 */
public class Usuario {
    private BasicDataSource bd1 = new BasicDataSource();
    private JdbcTemplate jdbcTemplate;
    
    
    
    
}
